# Bass-Invaders-AND-Space-Invaders
Using multiple restful APIs (YouTube and ChatGPT), users can request songs suggestions depending on their mood or what activities they are doing that day. ChatGPT will respond with a list of songs, along with a YouTube video. If you reach a wrong page / server error, no need to fear, the Easter bunny is here. 
